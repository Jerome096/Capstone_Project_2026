# Adviser Presentation Notes

## Online account demonstration
1. Choose **Order online**.
2. Log in with `customer@quvo.test / quvo123` or create a new account.
3. Show that the bottom navigation now contains **Menu, Cart, Track, Orders, Account**.
4. Open **Account**.
5. Edit the customer name, contact, email, or saved delivery address and save.
6. Return to Cart, choose **Delivery request**, and show that saved contact/address information can prefill the delivery fields.
7. Open **Account > Change password** to demonstrate account settings.
8. Open **My orders** to demonstrate account-linked order history.
9. Use **Log out** and show that the login session ends without deleting the account.
10. Log back in to demonstrate persistence.

## Dine-in distinction
Open `index.html?table=3` and explain that dine-in QR customers use temporary table sessions, so they do not see Online Account or Orders tabs.

## Important explanation
The UI behaves like the intended final application, but account/session/order synchronization is currently simulated in the browser. PHP/MySQL will replace localStorage and timed status simulations during backend integration.
