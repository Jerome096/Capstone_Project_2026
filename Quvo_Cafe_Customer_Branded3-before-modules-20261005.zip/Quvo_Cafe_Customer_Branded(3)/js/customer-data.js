const CUSTOMER_DATA = {
  tableNumber: "Table 1",
  categories: ["All", "Coffee", "Non-Coffee", "Pastries", "Meals"],
  menuItems: [
    {
      id: "coffee-spanish-latte",
      name: "Spanish Latte",
      category: "Coffee",
      price: 140,
      icon: "SL",
      description: "Creamy espresso-based drink with sweet milk notes."
    },
    {
      id: "coffee-caramel-macchiato",
      name: "Caramel Macchiato",
      category: "Coffee",
      price: 150,
      icon: "CM",
      description: "Espresso, milk, vanilla, and caramel drizzle."
    },
    {
      id: "coffee-americano",
      name: "Americano",
      category: "Coffee",
      price: 120,
      icon: "AM",
      description: "Bold espresso diluted with water for a clean finish."
    },
    {
      id: "noncoffee-matcha-latte",
      name: "Matcha Latte",
      category: "Non-Coffee",
      price: 145,
      icon: "ML",
      description: "Smooth matcha blended with milk and light sweetness."
    },
    {
      id: "noncoffee-chocolate-frappe",
      name: "Chocolate Frappe",
      category: "Non-Coffee",
      price: 155,
      icon: "CF",
      description: "Cold blended chocolate drink with a creamy texture."
    },
    {
      id: "noncoffee-strawberry-milk",
      name: "Strawberry Milk",
      category: "Non-Coffee",
      price: 135,
      icon: "SM",
      description: "Refreshing strawberry milk with a soft cafe-style flavor."
    },
    {
      id: "pastry-butter-croissant",
      name: "Butter Croissant",
      category: "Pastries",
      price: 95,
      icon: "BC",
      description: "Flaky, buttery pastry served warm."
    },
    {
      id: "pastry-blueberry-cheesecake",
      name: "Blueberry Cheesecake",
      category: "Pastries",
      price: 165,
      icon: "CH",
      description: "Creamy cheesecake topped with blueberry compote."
    },
    {
      id: "meal-chicken-pesto-pasta",
      name: "Chicken Pesto Pasta",
      category: "Meals",
      price: 185,
      icon: "PP",
      description: "Pasta with pesto sauce, chicken, and parmesan."
    },
    {
      id: "meal-beef-tapa-rice",
      name: "Beef Tapa Rice",
      category: "Meals",
      price: 180,
      icon: "TR",
      description: "Savory beef tapa served with rice and egg."
    }
  ],
  orderStatuses: [
    {
      key: "Received",
      title: "Received",
      description: "Your order has been submitted and is waiting for cashier payment confirmation."
    },
    {
      key: "Preparing",
      title: "Preparing",
      description: "The staff is preparing your food and drinks."
    },
    {
      key: "Ready",
      title: "Ready",
      description: "Your order is ready and will be served to your table."
    },
    {
      key: "Served",
      title: "Served",
      description: "Your order has been served. Thank you for ordering."
    }
  ]
,
  initialOnlineOrders: [
    {
      orderCode: "QVO-260912-014",
      accessMode: "online",
      source: "Online order",
      customerName: "Ana Reyes",
      accountEmail: "customer@quvo.test",
      contact: "0917 000 0000",
      tableNumber: "Not applicable",
      fulfillment: "Pickup",
      deliveryAddress: "",
      deliveryContact: "",
      paymentMethod: "GCash",
      submittedAt: "10:35 AM",
      total: 305,
      status: "Completed",
      statusIndex: 3,
      items: [
        { name: "Spanish Latte", quantity: 1, unitPrice: 140, category: "Coffee", customization: { size: "Regular", sugarLevel: "75%", iceLevel: "Less ice", addons: [], notes: "" } },
        { name: "Blueberry Cheesecake", quantity: 1, unitPrice: 165, category: "Pastries", customization: { size: "Regular", sugarLevel: "Not applicable", iceLevel: "Not applicable", addons: [], notes: "" } }
      ]
    },
    {
      orderCode: "QVO-260911-028",
      accessMode: "online",
      source: "Online order",
      customerName: "Ana Reyes",
      accountEmail: "customer@quvo.test",
      contact: "0917 000 0000",
      tableNumber: "Not applicable",
      fulfillment: "Staff-coordinated delivery request",
      deliveryAddress: "Molino Road, Bacoor City",
      deliveryContact: "0917 000 0000",
      paymentMethod: "PayMaya",
      submittedAt: "Yesterday",
      total: 330,
      status: "Completed",
      statusIndex: 3,
      items: [
        { name: "Caramel Macchiato", quantity: 1, unitPrice: 150, category: "Coffee", customization: { size: "Regular", sugarLevel: "100%", iceLevel: "Regular ice", addons: [], notes: "" } },
        { name: "Beef Tapa Rice", quantity: 1, unitPrice: 180, category: "Meals", customization: { size: "Regular", sugarLevel: "Not applicable", iceLevel: "Not applicable", addons: [], notes: "scrambled egg" } }
      ]
    }
  ]

};