const state = {
  currentScreen: "screenWelcome",
  accessMode: null,
  authMode: "login",
  customerName: "",
  onlineCustomer: null,
  selectedCategory: "All",
  searchTerm: "",
  selectedItem: null,
  modalQuantity: 1,
  cart: [],
  order: null,
  orderStatusIndex: 0,
  onlineOrders: [],
  accounts: [],
  sessionRequestCode: "",
  sessionApproved: false,
  sessionApprovalTimer: null,
  orderStatusTimers: []
};

const currencyFormatter = new Intl.NumberFormat("en-PH", {
  style: "currency",
  currency: "PHP"
});

const screens = document.querySelectorAll(".screen");
const bottomNav = document.querySelector(".bottom-nav");
const floatingCartBtn = document.getElementById("floatingCartBtn");
const toast = document.getElementById("toast");

const startDineInBtn = document.getElementById("startDineInBtn");
const startOnlineBtn = document.getElementById("startOnlineBtn");
const nameForm = document.getElementById("nameForm");
const customerNameInput = document.getElementById("customerName");
const nameError = document.getElementById("nameError");
const sessionRequestCode = document.getElementById("sessionRequestCode");
const sessionRequestStatus = document.getElementById("sessionRequestStatus");
const cancelSessionRequestBtn = document.getElementById("cancelSessionRequestBtn");

const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const loginError = document.getElementById("loginError");
const registerError = document.getElementById("registerError");

const categoryTabs = document.getElementById("categoryTabs");
const menuList = document.getElementById("menuList");
const menuSearch = document.getElementById("menuSearch");
const menuCount = document.getElementById("menuCount");
const accessModeLabel = document.getElementById("accessModeLabel");
const menuCustomerName = document.getElementById("menuCustomerName");
const menuContextLabel = document.getElementById("menuContextLabel");
const staffBtnHeader = document.getElementById("staffBtnHeader");

const cartItems = document.getElementById("cartItems");
const cartBadge = document.getElementById("cartBadge");
const floatingCartCount = document.getElementById("floatingCartCount");
const subtotalText = document.getElementById("subtotalText");
const totalText = document.getElementById("totalText");
const submitOrderBtn = document.getElementById("submitOrderBtn");
const fulfillmentCard = document.getElementById("fulfillmentCard");
const deliveryDetails = document.getElementById("deliveryDetails");
const paymentNote = document.getElementById("paymentNote");

const itemModal = document.getElementById("itemModal");
const customizeForm = document.getElementById("customizeForm");
const modalItemIcon = document.getElementById("modalItemIcon");
const modalItemCategory = document.getElementById("modalItemCategory");
const modalItemName = document.getElementById("modalItemName");
const modalItemDesc = document.getElementById("modalItemDesc");
const modalQty = document.getElementById("modalQty");
const decreaseQty = document.getElementById("decreaseQty");
const increaseQty = document.getElementById("increaseQty");
const drinkOptions = document.getElementById("drinkOptions");
const addToCartBtn = document.getElementById("addToCartBtn");

const trackingOrderCode = document.getElementById("trackingOrderCode");
const trackingPayment = document.getElementById("trackingPayment");
const statusTimeline = document.getElementById("statusTimeline");
const trackingDetails = document.getElementById("trackingDetails");
const trackingStatus = document.getElementById("trackingStatus");
const trackingUpdatedAt = document.getElementById("trackingUpdatedAt");
const historyList = document.getElementById("historyList");

const accountAvatar = document.getElementById("accountAvatar");
const accountDisplayName = document.getElementById("accountDisplayName");
const accountDisplayEmail = document.getElementById("accountDisplayEmail");
const profileForm = document.getElementById("profileForm");
const profileName = document.getElementById("profileName");
const profileEmail = document.getElementById("profileEmail");
const profileContact = document.getElementById("profileContact");
const profileAddress = document.getElementById("profileAddress");
const profileError = document.getElementById("profileError");
const profileSuccess = document.getElementById("profileSuccess");
const passwordForm = document.getElementById("passwordForm");
const currentPassword = document.getElementById("currentPassword");
const newPassword = document.getElementById("newPassword");
const confirmNewPassword = document.getElementById("confirmNewPassword");
const passwordError = document.getElementById("passwordError");
const passwordSuccess = document.getElementById("passwordSuccess");
const accountOrdersBtn = document.getElementById("accountOrdersBtn");
const logoutBtn = document.getElementById("logoutBtn");

const ONLINE_STORAGE_KEY = "quvo_customer_online_orders_v3";
const ACCOUNT_STORAGE_KEY = "quvo_customer_accounts_v1";
const ORDER_SEQUENCE_KEY = "quvo_customer_order_sequence_v1";
const ACTIVE_ACCOUNT_KEY = "quvo_customer_active_account_v1";

const seededAccount = {
  name: "Ana Reyes",
  email: "customer@quvo.test",
  password: "quvo123",
  contact: "0917 000 0000",
  address: "Molino, Bacoor City"
};

document.addEventListener("DOMContentLoaded", () => {
  const openedFromTableQr = applyTableContextFromUrl();
  state.onlineOrders = loadOnlineOrders();
  state.accounts = loadAccounts();
  setTableLabels();
  renderCategories();
  renderMenu();
  renderCart();
  renderTracking();
  renderHistory();
  bindEvents();

  if (openedFromTableQr) {
    startDineInFlow();
  } else if (restoreActiveOnlineSession()) {
    configureMenuHeader();
    renderHistory();
    renderAccount();
    prefillDeliveryDetails();
    showScreen("screenMenu");
  } else {
    showScreen("screenWelcome");
  }
});

function bindEvents() {
  startDineInBtn.addEventListener("click", startDineInFlow);
  startOnlineBtn.addEventListener("click", startOnlineFlow);
  nameForm.addEventListener("submit", handleNameSubmit);
  cancelSessionRequestBtn.addEventListener("click", cancelSessionRequest);
  loginForm.addEventListener("submit", handleLogin);
  registerForm.addEventListener("submit", handleRegister);

  document.querySelectorAll("[data-auth-tab]").forEach((button) => {
    button.addEventListener("click", () => switchAuthTab(button.dataset.authTab));
  });

  menuSearch.addEventListener("input", (event) => {
    state.searchTerm = event.target.value.trim().toLowerCase();
    renderMenu();
  });

  document.querySelectorAll("[data-nav]").forEach((button) => {
    button.addEventListener("click", () => {
      const nextScreen = button.dataset.nav;

      if (!canNavigateTo(nextScreen)) {
        return;
      }

      showScreen(nextScreen);
    });
  });

  document.querySelectorAll("[data-close-modal]").forEach((element) => {
    element.addEventListener("click", closeItemModal);
  });

  document.querySelectorAll("input[name='fulfillmentOption']").forEach((input) => {
    input.addEventListener("change", updateFulfillmentDisplay);
  });

  decreaseQty.addEventListener("click", () => {
    state.modalQuantity = Math.max(1, state.modalQuantity - 1);
    updateModalPrice();
  });

  increaseQty.addEventListener("click", () => {
    state.modalQuantity += 1;
    updateModalPrice();
  });

  customizeForm.addEventListener("change", updateModalPrice);
  customizeForm.addEventListener("submit", handleAddToCart);

  submitOrderBtn.addEventListener("click", submitOrder);
  floatingCartBtn.addEventListener("click", () => showScreen("screenCart"));
  staffBtnHeader.addEventListener("click", requestStaffAssistance);

  profileForm.addEventListener("submit", handleProfileUpdate);
  passwordForm.addEventListener("submit", handlePasswordUpdate);
  accountOrdersBtn.addEventListener("click", () => showScreen("screenHistory"));
  logoutBtn.addEventListener("click", logoutOnlineCustomer);

}

function applyTableContextFromUrl() {
  const params = new URLSearchParams(window.location.search);
  const tableParam = params.get("table");

  if (!tableParam) return false;

  const cleanTable = tableParam.trim().replace(/[^0-9A-Za-z-]/g, "").slice(0, 8);
  if (!cleanTable) return false;

  CUSTOMER_DATA.tableNumber = /^table/i.test(cleanTable)
    ? cleanTable.replace(/^table/i, "Table ")
    : `Table ${cleanTable}`;

  return true;
}

function setTableLabels() {
  document.getElementById("welcomeTableLabel").textContent = CUSTOMER_DATA.tableNumber;
  document.getElementById("waitingTableLabel").textContent = CUSTOMER_DATA.tableNumber;
}

function startDineInFlow() {
  state.accessMode = "dineIn";
  state.customerName = "";
  state.onlineCustomer = null;
  state.order = null;
  state.orderStatusIndex = 0;
  state.cart = [];
  state.sessionApproved = false;
  clearSessionApprovalTimer();
  clearOrderStatusTimers();
  renderCart();
  renderTracking();
  renderHistory();
  showScreen("screenDineInStart");
}

function startOnlineFlow() {
  state.accessMode = "online";
  state.customerName = "";
  state.onlineCustomer = null;
  state.order = null;
  state.orderStatusIndex = 0;
  state.cart = [];
  clearSessionApprovalTimer();
  clearOrderStatusTimers();
  renderCart();
  renderTracking();
  renderHistory();
  showScreen("screenOnlineAuth");
}

function switchAuthTab(tab) {
  state.authMode = tab;
  document.querySelectorAll(".auth-tab").forEach((button) => {
    button.classList.toggle("active", button.dataset.authTab === tab);
  });
  loginForm.classList.toggle("active", tab === "login");
  registerForm.classList.toggle("active", tab === "register");
  loginError.textContent = "";
  registerError.textContent = "";
}

function handleLogin(event) {
  event.preventDefault();

  const email = document.getElementById("loginEmail").value.trim().toLowerCase();
  const password = document.getElementById("loginPassword").value;

  if (!email || !password) {
    loginError.textContent = "Please enter your email and password.";
    return;
  }

  const account = state.accounts.find((entry) => entry.email.toLowerCase() === email && entry.password === password);

  if (!account) {
    loginError.textContent = "Invalid email or password.";
    return;
  }

  state.onlineCustomer = { ...account };
  state.customerName = account.name;
  persistActiveOnlineSession();
  loginError.textContent = "";
  configureMenuHeader();
  renderHistory();
  renderAccount();
  prefillDeliveryDetails();
  showToast(`Welcome back, ${account.name.split(" ")[0]}.`);
  showScreen("screenMenu");
}

function handleRegister(event) {
  event.preventDefault();

  const name = document.getElementById("registerName").value.trim();
  const contact = document.getElementById("registerContact").value.trim();
  const email = document.getElementById("registerEmail").value.trim().toLowerCase();
  const address = document.getElementById("registerAddress").value.trim();
  const password = document.getElementById("registerPassword").value;
  const confirmPassword = document.getElementById("registerPasswordConfirm").value;

  if (!name || !contact || !email || !password || !confirmPassword) {
    registerError.textContent = "Please complete all required fields.";
    return;
  }

  if (!email.includes("@")) {
    registerError.textContent = "Please enter a valid email address.";
    return;
  }

  if (password.length < 6) {
    registerError.textContent = "Password must be at least 6 characters.";
    return;
  }

  if (password !== confirmPassword) {
    registerError.textContent = "Passwords do not match.";
    return;
  }

  if (state.accounts.some((entry) => entry.email.toLowerCase() === email)) {
    registerError.textContent = "An account with this email already exists.";
    return;
  }

  const account = { name, contact, email, address, password };
  state.accounts.push(account);
  saveAccounts();

  state.onlineCustomer = { ...account };
  state.customerName = name;
  persistActiveOnlineSession();
  registerError.textContent = "";
  configureMenuHeader();
  renderHistory();
  renderAccount();
  prefillDeliveryDetails();
  showToast("Account created successfully.");
  showScreen("screenMenu");
}

function handleNameSubmit(event) {
  event.preventDefault();

  const name = customerNameInput.value.trim();

  if (!name) {
    nameError.textContent = "Please enter your name or nickname.";
    customerNameInput.focus();
    return;
  }

  if (name.length < 2) {
    nameError.textContent = "Name must be at least 2 characters.";
    customerNameInput.focus();
    return;
  }

  state.customerName = name;
  state.sessionApproved = false;
  state.sessionRequestCode = generateSessionRequestCode();
  nameError.textContent = "";
  configureMenuHeader();
  showScreen("screenWaiting");
  beginSessionApprovalWatch();
}

function beginSessionApprovalWatch() {
  clearSessionApprovalTimer();
  sessionRequestCode.textContent = state.sessionRequestCode;
  sessionRequestStatus.textContent = "Waiting for staff confirmation. This page updates automatically.";

  state.sessionApprovalTimer = window.setTimeout(() => {
    approveSession();
  }, 3500);
}

function approveSession() {
  clearSessionApprovalTimer();
  state.sessionApproved = true;
  sessionRequestStatus.textContent = "Approved. Opening the menu…";
  configureMenuHeader();
  showToast("Table session approved. You may now order.");
  window.setTimeout(() => showScreen("screenMenu"), 650);
}

function cancelSessionRequest() {
  clearSessionApprovalTimer();
  state.sessionRequestCode = "";
  state.sessionApproved = false;
  state.customerName = "";
  customerNameInput.value = "";
  showScreen("screenDineInStart");
}

function clearSessionApprovalTimer() {
  if (state.sessionApprovalTimer) {
    window.clearTimeout(state.sessionApprovalTimer);
    state.sessionApprovalTimer = null;
  }
}

function generateSessionRequestCode() {
  const table = CUSTOMER_DATA.tableNumber.replace(/[^0-9A-Za-z]/g, "").toUpperCase();
  const suffix = String(Math.floor(100 + Math.random() * 900));
  return `QVO-${table}-${suffix}`;
}

function configureMenuHeader() {
  if (state.accessMode === "online") {
    accessModeLabel.textContent = "Online order";
    menuCustomerName.textContent = state.customerName || "Online customer";
    menuContextLabel.textContent = "Pickup or delivery request";
    staffBtnHeader.style.display = "none";
    paymentNote.textContent = "Your selected payment method will be confirmed by Quvo Café staff before preparation begins.";
    fulfillmentCard.classList.remove("hidden");
    return;
  }

  accessModeLabel.textContent = "Dine-in QR";
  menuCustomerName.textContent = state.customerName || "Customer";
  menuContextLabel.textContent = CUSTOMER_DATA.tableNumber;
  staffBtnHeader.style.display = "inline-flex";
  paymentNote.textContent = "Your selected payment method will be confirmed by the cashier before preparation begins.";
  fulfillmentCard.classList.add("hidden");
}

function canNavigateTo(screenId) {
  if (screenId === "screenWelcome") {
    return true;
  }

  if (screenId === "screenDineInStart" || screenId === "screenOnlineAuth") {
    return true;
  }

  if (!state.accessMode) {
    showToast("Choose an ordering access mode first.");
    return false;
  }

  if (state.accessMode === "dineIn" && !state.sessionApproved) {
    showToast("Your table session must be approved before ordering.");
    return false;
  }

  if (state.accessMode === "online" && !state.onlineCustomer) {
    showToast("Please log in or register first.");
    return false;
  }

  if ((screenId === "screenHistory" || screenId === "screenAccount") && state.accessMode !== "online") {
    showToast("This section is available to online customer accounts only.");
    return false;
  }

  return true;
}

function showScreen(screenId) {
  if (state.currentScreen === "screenWaiting" && screenId !== "screenWaiting" && !state.sessionApproved) {
    clearSessionApprovalTimer();
  }

  state.currentScreen = screenId;

  screens.forEach((screen) => {
    screen.classList.toggle("screen-active", screen.id === screenId);
  });

  const appScreens = ["screenMenu", "screenCart", "screenTracking", "screenHistory", "screenAccount"];
  const shouldShowNav = appScreens.includes(screenId);

  bottomNav.style.display = shouldShowNav ? "grid" : "none";
  bottomNav.classList.toggle("online-mode", state.accessMode === "online" && Boolean(state.onlineCustomer));
  configureMenuHeader();
  updateNavState(screenId);
  updateFloatingCart();

  if (screenId === "screenHistory") {
    renderHistory();
  }

  if (screenId === "screenAccount") {
    renderAccount();
  }
}

function updateNavState(screenId) {
  document.querySelectorAll(".nav-btn").forEach((button) => {
    button.classList.toggle("active", button.dataset.nav === screenId);
  });
}

function renderCategories() {
  categoryTabs.innerHTML = CUSTOMER_DATA.categories
    .map((category) => {
      const activeClass = category === state.selectedCategory ? "active" : "";
      return `<button class="category-btn ${activeClass}" type="button" data-category="${category}">${category}</button>`;
    })
    .join("");

  document.querySelectorAll(".category-btn").forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedCategory = button.dataset.category;
      renderCategories();
      renderMenu();
    });
  });
}

function getFilteredMenuItems() {
  return CUSTOMER_DATA.menuItems.filter((item) => {
    const matchesCategory = state.selectedCategory === "All" || item.category === state.selectedCategory;
    const matchesSearch =
      item.name.toLowerCase().includes(state.searchTerm) ||
      item.category.toLowerCase().includes(state.searchTerm) ||
      item.description.toLowerCase().includes(state.searchTerm);

    return matchesCategory && matchesSearch;
  });
}

function renderMenu() {
  const items = getFilteredMenuItems();
  menuCount.textContent = `${items.length} item${items.length === 1 ? "" : "s"}`;

  if (!items.length) {
    menuList.innerHTML = `
      <div class="empty-card">
        <h3>No items found</h3>
        <p>Try another category or search term.</p>
      </div>
    `;
    return;
  }

  menuList.innerHTML = items
    .map((item) => {
      return `
        <article class="menu-card clickable-card" role="button" tabindex="0" data-card-item-id="${item.id}" aria-label="Customize ${item.name}">
          <div class="item-icon">${item.icon}</div>
          <div>
            <p class="eyebrow">${item.category}</p>
            <h3>${item.name}</h3>
            <p>${item.description}</p>
            <div class="card-bottom">
              <strong class="price">${formatCurrency(item.price)}</strong>
              <span class="tap-hint">Tap to customize</span>
            </div>
          </div>
        </article>
      `;
    })
    .join("");

  document.querySelectorAll("[data-card-item-id]").forEach((card) => {
    card.addEventListener("click", () => openItemModal(card.dataset.cardItemId));

    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openItemModal(card.dataset.cardItemId);
      }
    });
  });
}

function openItemModal(itemId) {
  const item = CUSTOMER_DATA.menuItems.find((menuItem) => menuItem.id === itemId);

  if (!item) {
    showToast("Item not found.");
    return;
  }

  state.selectedItem = item;
  state.modalQuantity = 1;

  customizeForm.reset();
  modalQty.textContent = "1";
  modalItemIcon.textContent = item.icon;
  modalItemCategory.textContent = item.category;
  modalItemName.textContent = item.name;
  modalItemDesc.textContent = item.description;

  const isDrink = item.category === "Coffee" || item.category === "Non-Coffee";
  drinkOptions.style.display = isDrink ? "grid" : "none";

  itemModal.classList.add("open");
  itemModal.setAttribute("aria-hidden", "false");
  updateModalPrice();
}

function closeItemModal() {
  itemModal.classList.remove("open");
  itemModal.setAttribute("aria-hidden", "true");
}

function getCustomizationSummary() {
  const formData = new FormData(customizeForm);
  const size = formData.get("size") || "Regular";
  const addons = formData.getAll("addons");
  const notes = document.getElementById("itemNotes").value.trim();
  const isDrink = state.selectedItem && ["Coffee", "Non-Coffee"].includes(state.selectedItem.category);

  return {
    size,
    sugarLevel: isDrink ? document.getElementById("sugarLevel").value : "Not applicable",
    iceLevel: isDrink ? document.getElementById("iceLevel").value : "Not applicable",
    addons,
    notes
  };
}

function calculateModalUnitPrice() {
  if (!state.selectedItem) {
    return 0;
  }

  const formData = new FormData(customizeForm);
  const size = formData.get("size") || "Regular";
  const selectedAddons = [...customizeForm.querySelectorAll("input[name='addons']:checked")];

  const sizePrice = size === "Large" ? 20 : 0;
  const addonsPrice = selectedAddons.reduce((sum, addon) => sum + Number(addon.dataset.price || 0), 0);

  return state.selectedItem.price + sizePrice + addonsPrice;
}

function updateModalPrice() {
  modalQty.textContent = state.modalQuantity;

  if (!state.selectedItem) {
    addToCartBtn.textContent = "Add to cart";
    return;
  }

  const total = calculateModalUnitPrice() * state.modalQuantity;
  addToCartBtn.textContent = `Add to cart · ${formatCurrency(total)}`;
}

function handleAddToCart(event) {
  event.preventDefault();

  if (!state.selectedItem) {
    return;
  }

  const customization = getCustomizationSummary();
  const unitPrice = calculateModalUnitPrice();
  const cartItem = {
    cartId: `${state.selectedItem.id}-${Date.now()}`,
    itemId: state.selectedItem.id,
    name: state.selectedItem.name,
    category: state.selectedItem.category,
    icon: state.selectedItem.icon,
    quantity: state.modalQuantity,
    unitPrice,
    customization
  };

  state.cart.push(cartItem);
  closeItemModal();
  renderCart();
  showToast(`${state.selectedItem.name} added to cart.`);
}

function renderCart() {
  const cartCount = getCartCount();
  const subtotal = getCartSubtotal();

  cartBadge.textContent = cartCount;
  floatingCartCount.textContent = cartCount;
  cartBadge.classList.toggle("visible", cartCount > 0);
  subtotalText.textContent = formatCurrency(subtotal);
  totalText.textContent = formatCurrency(subtotal);

  submitOrderBtn.disabled = cartCount === 0;
  updateFulfillmentDisplay();

  if (!state.cart.length) {
    cartItems.innerHTML = `
      <div class="empty-card">
        <h3>Your cart is empty</h3>
        <p>Go back to the menu and add your preferred food or drink.</p>
      </div>
    `;
    updateFloatingCart();
    return;
  }

  cartItems.innerHTML = state.cart
    .map((item) => {
      const addons = item.customization.addons.length ? item.customization.addons.join(", ") : "No add-ons";
      const notes = item.customization.notes || "No special instructions";

      return `
        <article class="cart-item">
          <div>
            <p class="eyebrow">${item.category}</p>
            <h3>${item.name}</h3>
            <strong class="price">${formatCurrency(item.unitPrice * item.quantity)}</strong>
            <div class="cart-meta">
              <span>Size: ${item.customization.size}</span>
              <span>Sugar: ${item.customization.sugarLevel}</span>
              <span>Ice: ${item.customization.iceLevel}</span>
              <span>Add-ons: ${addons}</span>
              <span>Notes: ${notes}</span>
            </div>
            <div class="cart-actions">
              <div class="cart-stepper">
                <button type="button" data-cart-minus="${item.cartId}">−</button>
                <strong>${item.quantity}</strong>
                <button type="button" data-cart-plus="${item.cartId}">+</button>
              </div>
              <button class="remove-btn" type="button" data-cart-remove="${item.cartId}">Remove</button>
            </div>
          </div>
        </article>
      `;
    })
    .join("");

  bindCartButtons();
  updateFloatingCart();
}

function bindCartButtons() {
  document.querySelectorAll("[data-cart-minus]").forEach((button) => {
    button.addEventListener("click", () => updateCartQuantity(button.dataset.cartMinus, -1));
  });

  document.querySelectorAll("[data-cart-plus]").forEach((button) => {
    button.addEventListener("click", () => updateCartQuantity(button.dataset.cartPlus, 1));
  });

  document.querySelectorAll("[data-cart-remove]").forEach((button) => {
    button.addEventListener("click", () => removeCartItem(button.dataset.cartRemove));
  });
}

function updateCartQuantity(cartId, change) {
  const item = state.cart.find((cartItem) => cartItem.cartId === cartId);

  if (!item) {
    return;
  }

  item.quantity += change;

  if (item.quantity <= 0) {
    removeCartItem(cartId);
    return;
  }

  renderCart();
}

function removeCartItem(cartId) {
  state.cart = state.cart.filter((item) => item.cartId !== cartId);
  renderCart();
  showToast("Item removed from cart.");
}

function updateFulfillmentDisplay() {
  const isOnline = state.accessMode === "online";
  fulfillmentCard.classList.toggle("hidden", !isOnline);

  const selectedFulfillment = getSelectedFulfillment();
  const isDelivery = isOnline && selectedFulfillment === "Staff-coordinated delivery request";
  deliveryDetails.classList.toggle("hidden", !isDelivery);

  if (isDelivery) {
    prefillDeliveryDetails();
  }
}

function getSelectedFulfillment() {
  const selected = document.querySelector("input[name='fulfillmentOption']:checked");
  return selected ? selected.value : "Pickup";
}

function submitOrder() {
  if (!state.cart.length) {
    showToast("Add at least one item before submitting.");
    return;
  }

  if (state.accessMode === "online" && !state.onlineCustomer) {
    showToast("Please log in or register first.");
    return;
  }

  const fulfillment = state.accessMode === "online" ? getSelectedFulfillment() : "Dine-in table service";
  const deliveryAddress = document.getElementById("deliveryAddress").value.trim();
  const deliveryContact = document.getElementById("deliveryContact").value.trim();

  if (fulfillment === "Staff-coordinated delivery request" && (!deliveryAddress || !deliveryContact)) {
    showToast("Please enter delivery address and contact details for staff reference.");
    return;
  }

  const paymentMethod = document.querySelector("input[name='paymentMethod']:checked").value;
  const now = new Date();
  const orderCode = generateOrderCode(now);

  state.order = {
    orderCode,
    accessMode: state.accessMode,
    source: state.accessMode === "online" ? "Online order" : "Dine-in QR",
    customerName: state.customerName,
    tableNumber: state.accessMode === "dineIn" ? CUSTOMER_DATA.tableNumber : "Not applicable",
    accountEmail: state.onlineCustomer ? state.onlineCustomer.email : "Not applicable",
    contact: state.onlineCustomer ? state.onlineCustomer.contact : "Not applicable",
    fulfillment,
    deliveryAddress,
    deliveryContact,
    paymentMethod,
    submittedAt: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    items: [...state.cart],
    total: getCartSubtotal(),
    status: "Received",
    statusIndex: 0,
    lastUpdated: now.toISOString()
  };

  state.orderStatusIndex = 0;
  state.cart = [];

  if (state.accessMode === "online") {
    addOrderToOnlineHistory(state.order);
  }

  renderCart();
  renderTracking();
  renderHistory();
  showToast("Order submitted successfully.");
  showScreen("screenTracking");
  startOrderStatusWatch();
}

function renderTracking() {
  if (!state.order) {
    trackingOrderCode.textContent = "No order yet";
    trackingPayment.textContent = "Payment";
    statusTimeline.innerHTML = CUSTOMER_DATA.orderStatuses
      .map((status) => {
        return `
          <article class="timeline-item">
            <div class="timeline-dot">•</div>
            <div>
              <h3>${status.title}</h3>
              <p>${status.description}</p>
            </div>
          </article>
        `;
      })
      .join("");

    trackingDetails.innerHTML = `
      <div class="empty-card">
        <h3>No submitted order</h3>
        <p>Your order details will appear here after you submit your cart.</p>
      </div>
    `;
    trackingStatus.textContent = "Waiting";
    trackingUpdatedAt.textContent = "Waiting for an order";
    return;
  }

  trackingOrderCode.textContent = state.order.orderCode;
  trackingPayment.textContent = state.order.paymentMethod;
  trackingStatus.textContent = getDisplayStatusTitle(CUSTOMER_DATA.orderStatuses[state.orderStatusIndex]);
  trackingUpdatedAt.textContent = `Last updated ${formatUpdateTime(state.order.lastUpdated)}`;

  statusTimeline.innerHTML = CUSTOMER_DATA.orderStatuses
    .map((status, index) => {
      const doneClass = index < state.orderStatusIndex ? "done" : "";
      const currentClass = index === state.orderStatusIndex ? "current" : "";
      const symbol = index < state.orderStatusIndex ? "✓" : index + 1;

      return `
        <article class="timeline-item ${doneClass} ${currentClass}">
          <div class="timeline-dot">${symbol}</div>
          <div>
            <h3>${status.title}</h3>
            <p>${getStatusDescription(status)}</p>
          </div>
        </article>
      `;
    })
    .join("");

  const itemRows = state.order.items
    .map((item) => {
      return `
        <div class="ticket-row">
          <span>${item.quantity} × ${item.name}</span>
          <strong>${formatCurrency(item.unitPrice * item.quantity)}</strong>
        </div>
      `;
    })
    .join("");

  const deliveryRows = state.order.fulfillment === "Staff-coordinated delivery request"
    ? `
      <div class="ticket-row">
        <span>Delivery address</span>
        <strong>${state.order.deliveryAddress}</strong>
      </div>
      <div class="ticket-row">
        <span>Receiver contact</span>
        <strong>${state.order.deliveryContact}</strong>
      </div>
    `
    : "";

  trackingDetails.innerHTML = `
    <p class="eyebrow">Order details</p>
    <div class="ticket-row">
      <span>Source</span>
      <strong>${state.order.source}</strong>
    </div>
    <div class="ticket-row">
      <span>Customer</span>
      <strong>${state.order.customerName}</strong>
    </div>
    <div class="ticket-row">
      <span>${state.order.accessMode === "online" ? "Account" : "Table"}</span>
      <strong>${state.order.accessMode === "online" ? state.order.accountEmail : state.order.tableNumber}</strong>
    </div>
    <div class="ticket-row">
      <span>Fulfillment</span>
      <strong>${state.order.fulfillment}</strong>
    </div>
    ${deliveryRows}
    <div class="ticket-row">
      <span>Submitted</span>
      <strong>${state.order.submittedAt}</strong>
    </div>
    ${itemRows}
    <div class="ticket-row">
      <span>Total</span>
      <strong>${formatCurrency(state.order.total)}</strong>
    </div>
  `;
}

function getDisplayStatusTitle(status) {
  if (state.order && state.order.accessMode === "online" && status.key === "Served") {
    return "Completed";
  }

  return status.title;
}

function getStatusDescription(status) {
  if (!state.order || state.order.accessMode !== "online") {
    return status.description;
  }

  const onlineDescriptions = {
    Received: "Your online order has been submitted and is waiting for staff payment and fulfillment review.",
    Preparing: "The staff is preparing your order based on the selected fulfillment option.",
    Ready: state.order.fulfillment === "Pickup" ? "Your order is ready for pickup." : "Your order is ready for staff-coordinated courier booking.",
    Served: "Your online order has been completed based on the selected fulfillment process."
  };

  return onlineDescriptions[status.key] || status.description;
}

function startOrderStatusWatch() {
  clearOrderStatusTimers();
  if (!state.order) return;

  const orderCode = state.order.orderCode;
  const steps = [
    { delay: 6500, statusIndex: 1 },
    { delay: 15000, statusIndex: 2 },
    { delay: 26000, statusIndex: 3 }
  ];

  state.orderStatusTimers = steps.map(({ delay, statusIndex }) => window.setTimeout(() => {
    if (!state.order || state.order.orderCode !== orderCode) return;
    if (state.orderStatusIndex >= statusIndex) return;

    state.orderStatusIndex = statusIndex;
    state.order.statusIndex = statusIndex;
    state.order.status = getDisplayStatusTitle(CUSTOMER_DATA.orderStatuses[statusIndex]);
    state.order.lastUpdated = new Date().toISOString();
    syncCurrentOrderToHistory();
    renderTracking();

    if (state.currentScreen === "screenTracking") {
      showToast(`Order updated: ${state.order.status}.`);
    }
  }, delay));
}

function clearOrderStatusTimers() {
  state.orderStatusTimers.forEach((timer) => window.clearTimeout(timer));
  state.orderStatusTimers = [];
}

function syncCurrentOrderToHistory() {
  if (!state.order || state.order.accessMode !== "online") return;
  const existing = state.onlineOrders.find((entry) => entry.orderCode === state.order.orderCode);
  if (!existing) return;

  existing.status = state.order.status;
  existing.statusIndex = state.order.statusIndex;
  existing.lastUpdated = state.order.lastUpdated;
  saveOnlineOrders();
  renderHistory();
}

function formatUpdateTime(value) {
  if (!value) return "just now";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "just now";
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function generateOrderCode(now = new Date()) {
  const dateKey = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;
  let sequence = { date: dateKey, count: 0 };

  try {
    const saved = JSON.parse(window.localStorage.getItem(ORDER_SEQUENCE_KEY) || "null");
    if (saved && saved.date === dateKey) sequence = saved;
  } catch (error) {
    sequence = { date: dateKey, count: 0 };
  }

  sequence.count += 1;
  window.localStorage.setItem(ORDER_SEQUENCE_KEY, JSON.stringify(sequence));
  const shortDate = dateKey.slice(2);
  return `QVO-${shortDate}-${String(sequence.count).padStart(3, "0")}`;
}

function requestStaffAssistance() {
  if (state.accessMode !== "dineIn") {
    showToast("Staff assistance is available for dine-in table QR sessions only.");
    return;
  }

  if (!state.customerName) {
    showToast("Please request approval first.");
    return;
  }

  showToast(`Staff assistance requested for ${CUSTOMER_DATA.tableNumber}.`);
}

function renderHistory() {
  if (state.accessMode !== "online" || !state.onlineCustomer) {
    historyList.innerHTML = `
      <div class="empty-card">
        <h3>Online account required</h3>
        <p>Order history is available only for registered online customer access.</p>
      </div>
    `;
    return;
  }

  const orders = state.onlineOrders.filter((order) => order.accountEmail === state.onlineCustomer.email);

  if (!orders.length) {
    historyList.innerHTML = `
      <div class="empty-card">
        <h3>No online order history yet</h3>
        <p>Submitted online orders will appear here with their fulfillment and payment details.</p>
      </div>
    `;
    return;
  }

  historyList.innerHTML = orders
    .map((order) => {
      return `
        <article class="history-card">
          <div class="history-head">
            <div>
              <p class="eyebrow">${order.source}</p>
              <h3>${order.orderCode}</h3>
            </div>
            <span class="count-pill">${order.status || "Completed"}</span>
          </div>
          <div class="ticket-row">
            <span>Fulfillment</span>
            <strong>${order.fulfillment}</strong>
          </div>
          <div class="ticket-row">
            <span>Payment</span>
            <strong>${order.paymentMethod}</strong>
          </div>
          <div class="ticket-row">
            <span>Items</span>
            <strong>${order.items.length}</strong>
          </div>
          <div class="ticket-row">
            <span>Total</span>
            <strong>${formatCurrency(order.total)}</strong>
          </div>
          <p class="small-copy">Submitted at ${order.submittedAt}.</p>
        </article>
      `;
    })
    .join("");
}

function addOrderToOnlineHistory(order) {
  order.status = order.status || "Received";
  order.statusIndex = Number.isInteger(order.statusIndex) ? order.statusIndex : 0;
  state.onlineOrders = [order, ...state.onlineOrders.filter((entry) => entry.orderCode !== order.orderCode)];
  saveOnlineOrders();
}

function loadAccounts() {
  const stored = window.localStorage.getItem(ACCOUNT_STORAGE_KEY);

  if (!stored) {
    return [{ ...seededAccount }];
  }

  try {
    const parsed = JSON.parse(stored);
    if (!Array.isArray(parsed)) return [{ ...seededAccount }];

    const accounts = parsed.map((entry) => ({ ...entry }));
    const hasSeededAccount = accounts.some((entry) => String(entry.email || "").toLowerCase() === seededAccount.email.toLowerCase());

    if (!hasSeededAccount) {
      accounts.unshift({ ...seededAccount });
    }

    return accounts;
  } catch (error) {
    return [{ ...seededAccount }];
  }
}

function saveAccounts() {
  window.localStorage.setItem(ACCOUNT_STORAGE_KEY, JSON.stringify(state.accounts));
}

function persistActiveOnlineSession() {
  if (!state.onlineCustomer?.email) return;
  window.localStorage.setItem(ACTIVE_ACCOUNT_KEY, state.onlineCustomer.email);
}

function clearActiveOnlineSession() {
  window.localStorage.removeItem(ACTIVE_ACCOUNT_KEY);
}

function restoreActiveOnlineSession() {
  const activeEmail = window.localStorage.getItem(ACTIVE_ACCOUNT_KEY);
  if (!activeEmail) return false;

  const account = state.accounts.find((entry) => String(entry.email || "").toLowerCase() === activeEmail.toLowerCase());
  if (!account) {
    clearActiveOnlineSession();
    return false;
  }

  state.accessMode = "online";
  state.onlineCustomer = { ...account };
  state.customerName = account.name;
  return true;
}

function renderAccount() {
  if (state.accessMode !== "online" || !state.onlineCustomer) {
    return;
  }

  const customer = state.onlineCustomer;
  const initials = String(customer.name || "Quvo Customer")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() || "")
    .join("") || "QC";

  accountAvatar.textContent = initials;
  accountDisplayName.textContent = customer.name || "Customer";
  accountDisplayEmail.textContent = customer.email || "";
  profileName.value = customer.name || "";
  profileEmail.value = customer.email || "";
  profileContact.value = customer.contact || "";
  profileAddress.value = customer.address || "";

  profileError.textContent = "";
  profileSuccess.textContent = "";
  passwordError.textContent = "";
  passwordSuccess.textContent = "";
}

function handleProfileUpdate(event) {
  event.preventDefault();

  if (!state.onlineCustomer) return;

  const name = profileName.value.trim();
  const email = profileEmail.value.trim().toLowerCase();
  const contact = profileContact.value.trim();
  const address = profileAddress.value.trim();
  const previousEmail = state.onlineCustomer.email;

  profileError.textContent = "";
  profileSuccess.textContent = "";

  if (!name || !email || !contact) {
    profileError.textContent = "Name, email, and contact number are required.";
    return;
  }

  if (!email.includes("@")) {
    profileError.textContent = "Please enter a valid email address.";
    return;
  }

  const duplicate = state.accounts.some((entry) => entry.email.toLowerCase() === email && entry.email.toLowerCase() !== previousEmail.toLowerCase());
  if (duplicate) {
    profileError.textContent = "Another account is already using this email address.";
    return;
  }

  const accountIndex = state.accounts.findIndex((entry) => entry.email.toLowerCase() === previousEmail.toLowerCase());
  if (accountIndex === -1) {
    profileError.textContent = "Your account could not be updated.";
    return;
  }

  const updatedAccount = {
    ...state.accounts[accountIndex],
    name,
    email,
    contact,
    address
  };

  state.accounts[accountIndex] = updatedAccount;
  state.onlineCustomer = { ...updatedAccount };
  state.customerName = name;

  if (email !== previousEmail.toLowerCase()) {
    state.onlineOrders = state.onlineOrders.map((order) => {
      if (String(order.accountEmail || "").toLowerCase() !== previousEmail.toLowerCase()) return order;
      return { ...order, accountEmail: email };
    });

    if (state.order && state.order.accessMode === "online" && String(state.order.accountEmail || "").toLowerCase() === previousEmail.toLowerCase()) {
      state.order.accountEmail = email;
    }

    saveOnlineOrders();
  }

  saveAccounts();
  persistActiveOnlineSession();
  configureMenuHeader();
  renderHistory();
  renderAccount();
  prefillDeliveryDetails(true);
  profileSuccess.textContent = "Profile changes saved.";
  showToast("Account profile updated.");
}

function handlePasswordUpdate(event) {
  event.preventDefault();

  if (!state.onlineCustomer) return;

  const current = currentPassword.value;
  const next = newPassword.value;
  const confirm = confirmNewPassword.value;

  passwordError.textContent = "";
  passwordSuccess.textContent = "";

  if (!current || !next || !confirm) {
    passwordError.textContent = "Please complete all password fields.";
    return;
  }

  if (current !== state.onlineCustomer.password) {
    passwordError.textContent = "Current password is incorrect.";
    return;
  }

  if (next.length < 6) {
    passwordError.textContent = "New password must be at least 6 characters.";
    return;
  }

  if (next !== confirm) {
    passwordError.textContent = "New passwords do not match.";
    return;
  }

  const accountIndex = state.accounts.findIndex((entry) => entry.email.toLowerCase() === state.onlineCustomer.email.toLowerCase());
  if (accountIndex === -1) return;

  state.accounts[accountIndex] = { ...state.accounts[accountIndex], password: next };
  state.onlineCustomer = { ...state.onlineCustomer, password: next };
  saveAccounts();

  passwordForm.reset();
  passwordSuccess.textContent = "Password updated successfully.";
  showToast("Password updated.");
}

function prefillDeliveryDetails(force = false) {
  if (!state.onlineCustomer) return;

  const addressField = document.getElementById("deliveryAddress");
  const contactField = document.getElementById("deliveryContact");

  if (addressField && (force || !addressField.value.trim())) {
    addressField.value = state.onlineCustomer.address || "";
  }

  if (contactField && (force || !contactField.value.trim())) {
    contactField.value = state.onlineCustomer.contact || "";
  }
}

function logoutOnlineCustomer() {
  clearActiveOnlineSession();
  clearOrderStatusTimers();
  clearSessionApprovalTimer();

  state.accessMode = "online";
  state.customerName = "";
  state.onlineCustomer = null;
  state.order = null;
  state.orderStatusIndex = 0;
  state.cart = [];
  state.searchTerm = "";
  state.selectedCategory = "All";

  loginForm.reset();
  registerForm.reset();
  profileForm.reset();
  passwordForm.reset();
  switchAuthTab("login");
  renderCart();
  renderTracking();
  renderHistory();
  showScreen("screenOnlineAuth");
  showToast("You have been logged out.");
}

function loadOnlineOrders() {
  const stored = window.localStorage.getItem(ONLINE_STORAGE_KEY);

  if (!stored) {
    return CUSTOMER_DATA.initialOnlineOrders || [];
  }

  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed : CUSTOMER_DATA.initialOnlineOrders || [];
  } catch (error) {
    return CUSTOMER_DATA.initialOnlineOrders || [];
  }
}

function saveOnlineOrders() {
  window.localStorage.setItem(ONLINE_STORAGE_KEY, JSON.stringify(state.onlineOrders));
}

function updateFloatingCart() {
  const cartCount = getCartCount();
  const allowedScreen = state.currentScreen === "screenMenu" && cartCount > 0;
  floatingCartBtn.classList.toggle("visible", allowedScreen);
}

function getCartCount() {
  return state.cart.reduce((count, item) => count + item.quantity, 0);
}

function getCartSubtotal() {
  return state.cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
}

function formatCurrency(value) {
  return currencyFormatter.format(value);
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("visible");

  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => {
    toast.classList.remove("visible");
  }, 2200);
}
