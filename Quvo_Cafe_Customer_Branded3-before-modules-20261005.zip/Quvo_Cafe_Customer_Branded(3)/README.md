# Quvo Café Customer UI — Adviser-Ready Account Version

This package extends the adviser-ready customer front end with a complete online customer account experience while keeping the project front-end only.

## Added in this version
- Online Account tab in the bottom navigation.
- Editable profile: full name, email, contact number, and saved delivery address/notes.
- Saved delivery details automatically prefill delivery-request checkout fields.
- Change-password form with current-password verification.
- Logout button that removes the active login but keeps the registered account and order history.
- Active online login persists across page refreshes in the same browser through localStorage.
- Existing online order history is available as `Orders` and from the Account page.
- Account and Orders navigation are hidden for dine-in QR customers because dine-in uses a temporary table session rather than a registered account.

## Existing adviser-ready behavior retained
- Table-specific QR URLs such as `index.html?table=3`.
- Automatic front-end cashier approval simulation.
- Automatic front-end order status progression.
- Online registration and login.
- Menu browsing, item customization, cart, payment selection, pickup/delivery request, tracking, and order history.
- Quvo Café black-and-gold branding.

## Demo online account
- Email: `customer@quvo.test`
- Password: `quvo123`

You can also create a new account from the Register tab.

## How to run
1. Extract the ZIP.
2. Open the project folder in VS Code.
3. Open `index.html` using Live Server.
4. Use the normal landing page for online ordering, or use a table-specific URL such as `index.html?table=3` for dine-in QR ordering.

## Front-end-only limitation
Accounts, active login state, and order history are stored in browser localStorage for presentation purposes. In the production PHP/MySQL version, authentication and profile changes must be processed by the backend, passwords must be hashed, and authorization must be enforced server-side.
