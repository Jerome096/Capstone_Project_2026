const state = {
  currentScreen: "screenWelcome",
  accessMode: null,
  authMode: "login",
  customerName: "",
  onlineCustomer: null,
  selectedCategory: "All",
  searchTerm: "",
  selectedItem: null,
  modalQuantity: 1,
  cart: [],
  order: null,
  orderStatusIndex: 0,
  onlineOrders: []
};

const currencyFormatter = new Intl.NumberFormat("en-PH", {
  style: "currency",
  currency: "PHP"
});

const screens = document.querySelectorAll(".screen");
const bottomNav = document.querySelector(".bottom-nav");
const floatingCartBtn = document.getElementById("floatingCartBtn");
const toast = document.getElementById("toast");

const startDineInBtn = document.getElementById("startDineInBtn");
const startOnlineBtn = document.getElementById("startOnlineBtn");
const nameForm = document.getElementById("nameForm");
const customerNameInput = document.getElementById("customerName");
const nameError = document.getElementById("nameError");
const simulateApprovalBtn = document.getElementById("simulateApprovalBtn");

const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const loginError = document.getElementById("loginError");
const registerError = document.getElementById("registerError");

const categoryTabs = document.getElementById("categoryTabs");
const menuList = document.getElementById("menuList");
const menuSearch = document.getElementById("menuSearch");
const menuCount = document.getElementById("menuCount");
const accessModeLabel = document.getElementById("accessModeLabel");
const menuCustomerName = document.getElementById("menuCustomerName");
const menuContextLabel = document.getElementById("menuContextLabel");
const staffBtnHeader = document.getElementById("staffBtnHeader");

const cartItems = document.getElementById("cartItems");
const cartBadge = document.getElementById("cartBadge");
const floatingCartCount = document.getElementById("floatingCartCount");
const subtotalText = document.getElementById("subtotalText");
const totalText = document.getElementById("totalText");
const submitOrderBtn = document.getElementById("submitOrderBtn");
const fulfillmentCard = document.getElementById("fulfillmentCard");
const deliveryDetails = document.getElementById("deliveryDetails");
const paymentNote = document.getElementById("paymentNote");

const itemModal = document.getElementById("itemModal");
const customizeForm = document.getElementById("customizeForm");
const modalItemIcon = document.getElementById("modalItemIcon");
const modalItemCategory = document.getElementById("modalItemCategory");
const modalItemName = document.getElementById("modalItemName");
const modalItemDesc = document.getElementById("modalItemDesc");
const modalQty = document.getElementById("modalQty");
const decreaseQty = document.getElementById("decreaseQty");
const increaseQty = document.getElementById("increaseQty");
const drinkOptions = document.getElementById("drinkOptions");
const addToCartBtn = document.getElementById("addToCartBtn");

const trackingOrderCode = document.getElementById("trackingOrderCode");
const trackingPayment = document.getElementById("trackingPayment");
const statusTimeline = document.getElementById("statusTimeline");
const trackingDetails = document.getElementById("trackingDetails");
const simulateStatusBtn = document.getElementById("simulateStatusBtn");
const historyList = document.getElementById("historyList");

const ONLINE_STORAGE_KEY = "quvo_customer_online_orders_v2";

const demoAccount = {
  name: "Ana Reyes",
  email: "customer@quvo.test",
  password: "quvo123",
  contact: "0917 000 0000",
  address: "Molino, Bacoor City"
};

document.addEventListener("DOMContentLoaded", () => {
  state.onlineOrders = loadOnlineOrders();
  setTableLabels();
  renderCategories();
  renderMenu();
  renderCart();
  renderTracking();
  renderHistory();
  bindEvents();
  showScreen("screenWelcome");
});

function bindEvents() {
  startDineInBtn.addEventListener("click", startDineInFlow);
  startOnlineBtn.addEventListener("click", startOnlineFlow);
  nameForm.addEventListener("submit", handleNameSubmit);
  simulateApprovalBtn.addEventListener("click", approveSession);
  loginForm.addEventListener("submit", handleLogin);
  registerForm.addEventListener("submit", handleRegister);

  document.querySelectorAll("[data-auth-tab]").forEach((button) => {
    button.addEventListener("click", () => switchAuthTab(button.dataset.authTab));
  });

  menuSearch.addEventListener("input", (event) => {
    state.searchTerm = event.target.value.trim().toLowerCase();
    renderMenu();
  });

  document.querySelectorAll("[data-nav]").forEach((button) => {
    button.addEventListener("click", () => {
      const nextScreen = button.dataset.nav;

      if (!canNavigateTo(nextScreen)) {
        return;
      }

      showScreen(nextScreen);
    });
  });

  document.querySelectorAll("[data-close-modal]").forEach((element) => {
    element.addEventListener("click", closeItemModal);
  });

  document.querySelectorAll("input[name='fulfillmentOption']").forEach((input) => {
    input.addEventListener("change", updateFulfillmentDisplay);
  });

  decreaseQty.addEventListener("click", () => {
    state.modalQuantity = Math.max(1, state.modalQuantity - 1);
    updateModalPrice();
  });

  increaseQty.addEventListener("click", () => {
    state.modalQuantity += 1;
    updateModalPrice();
  });

  customizeForm.addEventListener("change", updateModalPrice);
  customizeForm.addEventListener("submit", handleAddToCart);

  submitOrderBtn.addEventListener("click", submitOrder);
  floatingCartBtn.addEventListener("click", () => showScreen("screenCart"));
  staffBtnHeader.addEventListener("click", requestStaffAssistance);
  simulateStatusBtn.addEventListener("click", moveOrderStatus);
}

function setTableLabels() {
  document.getElementById("welcomeTableLabel").textContent = CUSTOMER_DATA.tableNumber;
  document.getElementById("waitingTableLabel").textContent = CUSTOMER_DATA.tableNumber;
}

function startDineInFlow() {
  state.accessMode = "dineIn";
  state.customerName = "";
  state.onlineCustomer = null;
  state.order = null;
  state.orderStatusIndex = 0;
  state.cart = [];
  renderCart();
  renderTracking();
  renderHistory();
  showScreen("screenDineInStart");
}

function startOnlineFlow() {
  state.accessMode = "online";
  state.customerName = "";
  state.onlineCustomer = null;
  state.order = null;
  state.orderStatusIndex = 0;
  state.cart = [];
  renderCart();
  renderTracking();
  renderHistory();
  showScreen("screenOnlineAuth");
}

function switchAuthTab(tab) {
  state.authMode = tab;
  document.querySelectorAll(".auth-tab").forEach((button) => {
    button.classList.toggle("active", button.dataset.authTab === tab);
  });
  loginForm.classList.toggle("active", tab === "login");
  registerForm.classList.toggle("active", tab === "register");
  loginError.textContent = "";
  registerError.textContent = "";
}

function handleLogin(event) {
  event.preventDefault();

  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value.trim();

  if (!email || !password) {
    loginError.textContent = "Please enter your email and password.";
    return;
  }

  if (email !== demoAccount.email || password !== demoAccount.password) {
    loginError.textContent = "Use the demo account shown above for this prototype.";
    return;
  }

  state.onlineCustomer = { ...demoAccount };
  state.customerName = demoAccount.name;
  configureMenuHeader();
  renderHistory();
  showToast("Online account verified.");
  showScreen("screenMenu");
}

function handleRegister(event) {
  event.preventDefault();

  const name = document.getElementById("registerName").value.trim();
  const contact = document.getElementById("registerContact").value.trim();
  const email = document.getElementById("registerEmail").value.trim();
  const address = document.getElementById("registerAddress").value.trim();

  if (!name || !contact || !email) {
    registerError.textContent = "Please provide your name, contact number, and email.";
    return;
  }

  state.onlineCustomer = {
    name,
    contact,
    email,
    address,
    password: "demo-only"
  };
  state.customerName = name;
  configureMenuHeader();
  renderHistory();
  showToast("Demo account created. You may now place an online order.");
  showScreen("screenMenu");
}

function handleNameSubmit(event) {
  event.preventDefault();

  const name = customerNameInput.value.trim();

  if (!name) {
    nameError.textContent = "Please enter your name or nickname.";
    customerNameInput.focus();
    return;
  }

  if (name.length < 2) {
    nameError.textContent = "Name must be at least 2 characters.";
    customerNameInput.focus();
    return;
  }

  state.customerName = name;
  nameError.textContent = "";
  configureMenuHeader();
  showScreen("screenWaiting");
}

function approveSession() {
  configureMenuHeader();
  showToast("Session approved. You may now browse the menu.");
  showScreen("screenMenu");
}

function configureMenuHeader() {
  if (state.accessMode === "online") {
    accessModeLabel.textContent = "Online order";
    menuCustomerName.textContent = state.customerName || "Online customer";
    menuContextLabel.textContent = "Pickup or delivery request";
    staffBtnHeader.style.display = "none";
    paymentNote.textContent = "Online payment details are recorded for staff review. Final confirmation still depends on the approved payment method and staff verification.";
    fulfillmentCard.classList.remove("hidden");
    return;
  }

  accessModeLabel.textContent = "Dine-in QR";
  menuCustomerName.textContent = state.customerName || "Customer";
  menuContextLabel.textContent = CUSTOMER_DATA.tableNumber;
  staffBtnHeader.style.display = "inline-flex";
  paymentNote.textContent = "Payment is selected for cashier confirmation. Cash, GCash, and PayMaya still require staff verification before preparation.";
  fulfillmentCard.classList.add("hidden");
}

function canNavigateTo(screenId) {
  if (screenId === "screenWelcome") {
    return true;
  }

  if (screenId === "screenDineInStart" || screenId === "screenOnlineAuth") {
    return true;
  }

  if (!state.accessMode) {
    showToast("Choose an ordering access mode first.");
    return false;
  }

  if (state.accessMode === "dineIn" && !state.customerName) {
    showToast("Please request cashier approval first.");
    return false;
  }

  if (state.accessMode === "online" && !state.onlineCustomer) {
    showToast("Please log in or register first.");
    return false;
  }

  return true;
}

function showScreen(screenId) {
  state.currentScreen = screenId;

  screens.forEach((screen) => {
    screen.classList.toggle("screen-active", screen.id === screenId);
  });

  const appScreens = ["screenMenu", "screenCart", "screenTracking", "screenHistory"];
  const shouldShowNav = appScreens.includes(screenId);

  bottomNav.style.display = shouldShowNav ? "grid" : "none";
  configureMenuHeader();
  updateNavState(screenId);
  updateFloatingCart();

  if (screenId === "screenHistory") {
    renderHistory();
  }
}

function updateNavState(screenId) {
  document.querySelectorAll(".nav-btn").forEach((button) => {
    button.classList.toggle("active", button.dataset.nav === screenId);
  });
}

function renderCategories() {
  categoryTabs.innerHTML = CUSTOMER_DATA.categories
    .map((category) => {
      const activeClass = category === state.selectedCategory ? "active" : "";
      return `<button class="category-btn ${activeClass}" type="button" data-category="${category}">${category}</button>`;
    })
    .join("");

  document.querySelectorAll(".category-btn").forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedCategory = button.dataset.category;
      renderCategories();
      renderMenu();
    });
  });
}

function getFilteredMenuItems() {
  return CUSTOMER_DATA.menuItems.filter((item) => {
    const matchesCategory = state.selectedCategory === "All" || item.category === state.selectedCategory;
    const matchesSearch =
      item.name.toLowerCase().includes(state.searchTerm) ||
      item.category.toLowerCase().includes(state.searchTerm) ||
      item.description.toLowerCase().includes(state.searchTerm);

    return matchesCategory && matchesSearch;
  });
}

function renderMenu() {
  const items = getFilteredMenuItems();
  menuCount.textContent = `${items.length} item${items.length === 1 ? "" : "s"}`;

  if (!items.length) {
    menuList.innerHTML = `
      <div class="empty-card">
        <h3>No items found</h3>
        <p>Try another category or search term.</p>
      </div>
    `;
    return;
  }

  menuList.innerHTML = items
    .map((item) => {
      return `
        <article class="menu-card clickable-card" role="button" tabindex="0" data-card-item-id="${item.id}" aria-label="Customize ${item.name}">
          <div class="item-icon">${item.icon}</div>
          <div>
            <p class="eyebrow">${item.category}</p>
            <h3>${item.name}</h3>
            <p>${item.description}</p>
            <div class="card-bottom">
              <strong class="price">${formatCurrency(item.price)}</strong>
              <span class="tap-hint">Tap to customize</span>
            </div>
          </div>
        </article>
      `;
    })
    .join("");

  document.querySelectorAll("[data-card-item-id]").forEach((card) => {
    card.addEventListener("click", () => openItemModal(card.dataset.cardItemId));

    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openItemModal(card.dataset.cardItemId);
      }
    });
  });
}

function openItemModal(itemId) {
  const item = CUSTOMER_DATA.menuItems.find((menuItem) => menuItem.id === itemId);

  if (!item) {
    showToast("Item not found.");
    return;
  }

  state.selectedItem = item;
  state.modalQuantity = 1;

  customizeForm.reset();
  modalQty.textContent = "1";
  modalItemIcon.textContent = item.icon;
  modalItemCategory.textContent = item.category;
  modalItemName.textContent = item.name;
  modalItemDesc.textContent = item.description;

  const isDrink = item.category === "Coffee" || item.category === "Non-Coffee";
  drinkOptions.style.display = isDrink ? "grid" : "none";

  itemModal.classList.add("open");
  itemModal.setAttribute("aria-hidden", "false");
  updateModalPrice();
}

function closeItemModal() {
  itemModal.classList.remove("open");
  itemModal.setAttribute("aria-hidden", "true");
}

function getCustomizationSummary() {
  const formData = new FormData(customizeForm);
  const size = formData.get("size") || "Regular";
  const addons = formData.getAll("addons");
  const notes = document.getElementById("itemNotes").value.trim();
  const isDrink = state.selectedItem && ["Coffee", "Non-Coffee"].includes(state.selectedItem.category);

  return {
    size,
    sugarLevel: isDrink ? document.getElementById("sugarLevel").value : "Not applicable",
    iceLevel: isDrink ? document.getElementById("iceLevel").value : "Not applicable",
    addons,
    notes
  };
}

function calculateModalUnitPrice() {
  if (!state.selectedItem) {
    return 0;
  }

  const formData = new FormData(customizeForm);
  const size = formData.get("size") || "Regular";
  const selectedAddons = [...customizeForm.querySelectorAll("input[name='addons']:checked")];

  const sizePrice = size === "Large" ? 20 : 0;
  const addonsPrice = selectedAddons.reduce((sum, addon) => sum + Number(addon.dataset.price || 0), 0);

  return state.selectedItem.price + sizePrice + addonsPrice;
}

function updateModalPrice() {
  modalQty.textContent = state.modalQuantity;

  if (!state.selectedItem) {
    addToCartBtn.textContent = "Add to cart";
    return;
  }

  const total = calculateModalUnitPrice() * state.modalQuantity;
  addToCartBtn.textContent = `Add to cart · ${formatCurrency(total)}`;
}

function handleAddToCart(event) {
  event.preventDefault();

  if (!state.selectedItem) {
    return;
  }

  const customization = getCustomizationSummary();
  const unitPrice = calculateModalUnitPrice();
  const cartItem = {
    cartId: `${state.selectedItem.id}-${Date.now()}`,
    itemId: state.selectedItem.id,
    name: state.selectedItem.name,
    category: state.selectedItem.category,
    icon: state.selectedItem.icon,
    quantity: state.modalQuantity,
    unitPrice,
    customization
  };

  state.cart.push(cartItem);
  closeItemModal();
  renderCart();
  showToast(`${state.selectedItem.name} added to cart.`);
}

function renderCart() {
  const cartCount = getCartCount();
  const subtotal = getCartSubtotal();

  cartBadge.textContent = cartCount;
  floatingCartCount.textContent = cartCount;
  cartBadge.classList.toggle("visible", cartCount > 0);
  subtotalText.textContent = formatCurrency(subtotal);
  totalText.textContent = formatCurrency(subtotal);

  submitOrderBtn.disabled = cartCount === 0;
  updateFulfillmentDisplay();

  if (!state.cart.length) {
    cartItems.innerHTML = `
      <div class="empty-card">
        <h3>Your cart is empty</h3>
        <p>Go back to the menu and add your preferred food or drink.</p>
      </div>
    `;
    updateFloatingCart();
    return;
  }

  cartItems.innerHTML = state.cart
    .map((item) => {
      const addons = item.customization.addons.length ? item.customization.addons.join(", ") : "No add-ons";
      const notes = item.customization.notes || "No special instructions";

      return `
        <article class="cart-item">
          <div>
            <p class="eyebrow">${item.category}</p>
            <h3>${item.name}</h3>
            <strong class="price">${formatCurrency(item.unitPrice * item.quantity)}</strong>
            <div class="cart-meta">
              <span>Size: ${item.customization.size}</span>
              <span>Sugar: ${item.customization.sugarLevel}</span>
              <span>Ice: ${item.customization.iceLevel}</span>
              <span>Add-ons: ${addons}</span>
              <span>Notes: ${notes}</span>
            </div>
            <div class="cart-actions">
              <div class="cart-stepper">
                <button type="button" data-cart-minus="${item.cartId}">−</button>
                <strong>${item.quantity}</strong>
                <button type="button" data-cart-plus="${item.cartId}">+</button>
              </div>
              <button class="remove-btn" type="button" data-cart-remove="${item.cartId}">Remove</button>
            </div>
          </div>
        </article>
      `;
    })
    .join("");

  bindCartButtons();
  updateFloatingCart();
}

function bindCartButtons() {
  document.querySelectorAll("[data-cart-minus]").forEach((button) => {
    button.addEventListener("click", () => updateCartQuantity(button.dataset.cartMinus, -1));
  });

  document.querySelectorAll("[data-cart-plus]").forEach((button) => {
    button.addEventListener("click", () => updateCartQuantity(button.dataset.cartPlus, 1));
  });

  document.querySelectorAll("[data-cart-remove]").forEach((button) => {
    button.addEventListener("click", () => removeCartItem(button.dataset.cartRemove));
  });
}

function updateCartQuantity(cartId, change) {
  const item = state.cart.find((cartItem) => cartItem.cartId === cartId);

  if (!item) {
    return;
  }

  item.quantity += change;

  if (item.quantity <= 0) {
    removeCartItem(cartId);
    return;
  }

  renderCart();
}

function removeCartItem(cartId) {
  state.cart = state.cart.filter((item) => item.cartId !== cartId);
  renderCart();
  showToast("Item removed from cart.");
}

function updateFulfillmentDisplay() {
  const isOnline = state.accessMode === "online";
  fulfillmentCard.classList.toggle("hidden", !isOnline);

  const selectedFulfillment = getSelectedFulfillment();
  deliveryDetails.classList.toggle("hidden", !isOnline || selectedFulfillment !== "Staff-coordinated delivery request");
}

function getSelectedFulfillment() {
  const selected = document.querySelector("input[name='fulfillmentOption']:checked");
  return selected ? selected.value : "Pickup";
}

function submitOrder() {
  if (!state.cart.length) {
    showToast("Add at least one item before submitting.");
    return;
  }

  if (state.accessMode === "online" && !state.onlineCustomer) {
    showToast("Please log in or register first.");
    return;
  }

  const fulfillment = state.accessMode === "online" ? getSelectedFulfillment() : "Dine-in table service";
  const deliveryAddress = document.getElementById("deliveryAddress").value.trim();
  const deliveryContact = document.getElementById("deliveryContact").value.trim();

  if (fulfillment === "Staff-coordinated delivery request" && (!deliveryAddress || !deliveryContact)) {
    showToast("Please enter delivery address and contact details for staff reference.");
    return;
  }

  const paymentMethod = document.querySelector("input[name='paymentMethod']:checked").value;
  const now = new Date();
  const orderCode = `QC-${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}${String(now.getSeconds()).padStart(2, "0")}`;

  state.order = {
    orderCode,
    accessMode: state.accessMode,
    source: state.accessMode === "online" ? "Online order" : "Dine-in QR",
    customerName: state.customerName,
    tableNumber: state.accessMode === "dineIn" ? CUSTOMER_DATA.tableNumber : "Not applicable",
    accountEmail: state.onlineCustomer ? state.onlineCustomer.email : "Not applicable",
    contact: state.onlineCustomer ? state.onlineCustomer.contact : "Not applicable",
    fulfillment,
    deliveryAddress,
    deliveryContact,
    paymentMethod,
    submittedAt: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    items: [...state.cart],
    total: getCartSubtotal()
  };

  state.orderStatusIndex = 0;
  state.cart = [];

  if (state.accessMode === "online") {
    addOrderToOnlineHistory(state.order);
  }

  renderCart();
  renderTracking();
  renderHistory();
  showToast(state.accessMode === "online" ? "Online order submitted for staff review." : "Order submitted to cashier.");
  showScreen("screenTracking");
}

function renderTracking() {
  if (!state.order) {
    trackingOrderCode.textContent = "No order yet";
    trackingPayment.textContent = "Payment";
    statusTimeline.innerHTML = CUSTOMER_DATA.orderStatuses
      .map((status) => {
        return `
          <article class="timeline-item">
            <div class="timeline-dot">•</div>
            <div>
              <h3>${status.title}</h3>
              <p>${status.description}</p>
            </div>
          </article>
        `;
      })
      .join("");

    trackingDetails.innerHTML = `
      <div class="empty-card">
        <h3>No submitted order</h3>
        <p>Your order details will appear here after you submit your cart.</p>
      </div>
    `;
    simulateStatusBtn.disabled = true;
    return;
  }

  trackingOrderCode.textContent = state.order.orderCode;
  trackingPayment.textContent = state.order.paymentMethod;
  simulateStatusBtn.disabled = state.orderStatusIndex >= CUSTOMER_DATA.orderStatuses.length - 1;

  statusTimeline.innerHTML = CUSTOMER_DATA.orderStatuses
    .map((status, index) => {
      const doneClass = index < state.orderStatusIndex ? "done" : "";
      const currentClass = index === state.orderStatusIndex ? "current" : "";
      const symbol = index < state.orderStatusIndex ? "✓" : index + 1;

      return `
        <article class="timeline-item ${doneClass} ${currentClass}">
          <div class="timeline-dot">${symbol}</div>
          <div>
            <h3>${status.title}</h3>
            <p>${getStatusDescription(status)}</p>
          </div>
        </article>
      `;
    })
    .join("");

  const itemRows = state.order.items
    .map((item) => {
      return `
        <div class="ticket-row">
          <span>${item.quantity} × ${item.name}</span>
          <strong>${formatCurrency(item.unitPrice * item.quantity)}</strong>
        </div>
      `;
    })
    .join("");

  const deliveryRows = state.order.fulfillment === "Staff-coordinated delivery request"
    ? `
      <div class="ticket-row">
        <span>Delivery address</span>
        <strong>${state.order.deliveryAddress}</strong>
      </div>
      <div class="ticket-row">
        <span>Receiver contact</span>
        <strong>${state.order.deliveryContact}</strong>
      </div>
    `
    : "";

  trackingDetails.innerHTML = `
    <p class="eyebrow">Order details</p>
    <div class="ticket-row">
      <span>Source</span>
      <strong>${state.order.source}</strong>
    </div>
    <div class="ticket-row">
      <span>Customer</span>
      <strong>${state.order.customerName}</strong>
    </div>
    <div class="ticket-row">
      <span>${state.order.accessMode === "online" ? "Account" : "Table"}</span>
      <strong>${state.order.accessMode === "online" ? state.order.accountEmail : state.order.tableNumber}</strong>
    </div>
    <div class="ticket-row">
      <span>Fulfillment</span>
      <strong>${state.order.fulfillment}</strong>
    </div>
    ${deliveryRows}
    <div class="ticket-row">
      <span>Submitted</span>
      <strong>${state.order.submittedAt}</strong>
    </div>
    ${itemRows}
    <div class="ticket-row">
      <span>Total</span>
      <strong>${formatCurrency(state.order.total)}</strong>
    </div>
  `;
}

function getStatusDescription(status) {
  if (!state.order || state.order.accessMode !== "online") {
    return status.description;
  }

  const onlineDescriptions = {
    Received: "Your online order has been submitted and is waiting for staff payment and fulfillment review.",
    Preparing: "The staff is preparing your order based on the selected fulfillment option.",
    Ready: state.order.fulfillment === "Pickup" ? "Your order is ready for pickup." : "Your order is ready for staff-coordinated courier booking.",
    Served: "Your online order has been completed based on the selected fulfillment process."
  };

  return onlineDescriptions[status.key] || status.description;
}

function moveOrderStatus() {
  if (!state.order) {
    showToast("Submit an order first.");
    return;
  }

  if (state.orderStatusIndex < CUSTOMER_DATA.orderStatuses.length - 1) {
    state.orderStatusIndex += 1;
    renderTracking();

    const currentStatus = CUSTOMER_DATA.orderStatuses[state.orderStatusIndex].title;
    showToast(`Order status updated to ${currentStatus}.`);
  }
}

function requestStaffAssistance() {
  if (state.accessMode !== "dineIn") {
    showToast("Staff assistance is available for dine-in table QR sessions only.");
    return;
  }

  if (!state.customerName) {
    showToast("Please request approval first.");
    return;
  }

  showToast(`Staff assistance requested for ${CUSTOMER_DATA.tableNumber}.`);
}

function renderHistory() {
  if (state.accessMode !== "online" || !state.onlineCustomer) {
    historyList.innerHTML = `
      <div class="empty-card">
        <h3>Online account required</h3>
        <p>Order history is available only for registered online customer access.</p>
      </div>
    `;
    return;
  }

  const orders = state.onlineOrders.filter((order) => order.accountEmail === state.onlineCustomer.email);

  if (!orders.length) {
    historyList.innerHTML = `
      <div class="empty-card">
        <h3>No online order history yet</h3>
        <p>Submitted online orders will appear here with their fulfillment and payment details.</p>
      </div>
    `;
    return;
  }

  historyList.innerHTML = orders
    .map((order) => {
      return `
        <article class="history-card">
          <div class="history-head">
            <div>
              <p class="eyebrow">${order.source}</p>
              <h3>${order.orderCode}</h3>
            </div>
            <span class="count-pill">${order.paymentMethod}</span>
          </div>
          <div class="ticket-row">
            <span>Fulfillment</span>
            <strong>${order.fulfillment}</strong>
          </div>
          <div class="ticket-row">
            <span>Items</span>
            <strong>${order.items.length}</strong>
          </div>
          <div class="ticket-row">
            <span>Total</span>
            <strong>${formatCurrency(order.total)}</strong>
          </div>
          <p class="small-copy">Submitted at ${order.submittedAt}. This is a prototype record stored on this browser only.</p>
        </article>
      `;
    })
    .join("");
}

function addOrderToOnlineHistory(order) {
  state.onlineOrders = [order, ...state.onlineOrders.filter((entry) => entry.orderCode !== order.orderCode)];
  saveOnlineOrders();
}

function loadOnlineOrders() {
  const stored = window.localStorage.getItem(ONLINE_STORAGE_KEY);

  if (!stored) {
    return CUSTOMER_DATA.sampleOnlineOrders || [];
  }

  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? parsed : CUSTOMER_DATA.sampleOnlineOrders || [];
  } catch (error) {
    return CUSTOMER_DATA.sampleOnlineOrders || [];
  }
}

function saveOnlineOrders() {
  window.localStorage.setItem(ONLINE_STORAGE_KEY, JSON.stringify(state.onlineOrders));
}

function updateFloatingCart() {
  const cartCount = getCartCount();
  const allowedScreen = state.currentScreen === "screenMenu" && cartCount > 0;
  floatingCartBtn.classList.toggle("visible", allowedScreen);
}

function getCartCount() {
  return state.cart.reduce((count, item) => count + item.quantity, 0);
}

function getCartSubtotal() {
  return state.cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
}

function formatCurrency(value) {
  return currencyFormatter.format(value);
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("visible");

  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => {
    toast.classList.remove("visible");
  }, 2200);
}
