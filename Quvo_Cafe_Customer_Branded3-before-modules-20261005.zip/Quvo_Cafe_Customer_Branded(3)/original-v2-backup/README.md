# Quvo Cafe Customer Access Prototype V2

This module demonstrates the customer-facing side of the Quvo Cafe prototype.

## Included access modes

1. Dine-in table QR ordering
   - Customer scans a table QR code.
   - Customer enters a name or nickname.
   - Cashier approval is simulated before menu access.
   - Customer may browse the menu, customize items, submit an order, track status, and call staff.

2. Online ordering
   - Customer may log in using the demo account or create a demo account.
   - Online customers may browse the menu, customize items, select pickup or staff-coordinated delivery request, submit an order, track status, and view order history.
   - Delivery request records are for staff coordination only. Courier booking is still handled manually outside the system.

## Demo online account

- Email: customer@quvo.test
- Password: quvo123

## Payment methods

The checkout supports Cash, GCash, and PayMaya as payment selections. These selections are recorded for staff review and do not represent automatic payment verification.
